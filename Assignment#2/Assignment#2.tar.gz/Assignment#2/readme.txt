Name: BenKun Chen (30005337)

INTRODUCTION:

The program is been eddited based on the boilerlplate code for eclipse


CONTROLS:

1 - switch to "image1-mandrill" scene
2 - switch to "image2-uclogo" scene
3 - switch to "image3-aerial" scene
4 - switch to "image4-thirsk" scene
5 - switch to "image5-pattern" scene
6 - switch to "image6-bubble" scene
7 - switch to "Globe" scene

A - Image Effect 1
S - Image Effect 2
D - Image Effect 3
F - Image Effect 4
G - original image

Z - Vertical Sobel
X - Horizontal Sobel
C - Unsharp Mask

V - 3 X 3 Gausian
B - 5 X 5 Gausian
N - 7 X 7 Gausian

click and drag - transformation
scroll up - zoom in
scroll down - zoom out
left arrow key - rotate counter-clockwise
right arrow key - rotate clockwise


