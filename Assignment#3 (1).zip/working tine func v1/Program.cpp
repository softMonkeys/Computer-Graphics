/*
 * Program.cpp
 *
 *  Created on: Sep 10, 2018
 *      Author: John Hall
 */

#include "Program.h"

#include <iostream>
#include <string>
#include <ctime>

//**Must include glad and GLFW in this order or it breaks**
#include <glad/glad.h>
#include <GLFW/glfw3.h>

#include "RenderingEngine.h"
#include "Scene.h"

Scene* currentScene;

Program::Program() {
	setupWindow();
}

Program::~Program() {
	//Must be cleaned up in the destructor because these are allocated to the heap
	delete renderingEngine;
	delete scene;
}

void Program::start() {
	renderingEngine = new RenderingEngine();
	scene = new Scene(renderingEngine);

	currentScene = scene;
	Program* program = (Program*)glfwGetWindowUserPointer(window);

	//Main render loop
	while(!glfwWindowShouldClose(window)) {
		time_t time1 = clock();

		scene->displayScene((time1/10000.f)/program->getSpeed(), program->getSceneID());
		glfwSwapBuffers(window);
		glfwPollEvents();
	}
}

void Program::setupWindow() {
	//Initialize the GLFW windowing system
	if (!glfwInit()) {
		std::cout << "ERROR: GLFW failed to initialize, TERMINATING" << std::endl;
		return;
	}

	//Set the custom error callback function
	//Errors will be printed to the console
	glfwSetErrorCallback(ErrorCallback);

	//Attempt to create a window with an OpenGL 4.1 core profile context
	glfwWindowHint(GLFW_SAMPLES, 4);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 1);
	glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
	int width = 1024;
	int height = 1024;
	window = glfwCreateWindow(width, height, "CPSC 453 Assignment 3", 0, 0);
	if (!window) {
		std::cout << "Program failed to create GLFW window, TERMINATING" << std::endl;
		glfwTerminate();
		return;
	}

	//Set the custom function that tracks key presses
	glfwSetKeyCallback(window, KeyCallback);

	//Bring the new window to the foreground (not strictly necessary but convenient)
	glfwMakeContextCurrent(window);

	glfwSetWindowUserPointer(window, this);

	//Set the custom function that tracks scroll input
	glfwSetScrollCallback(window, scroll_callback);

	//Intialize GLAD (finds appropriate OpenGL configuration for your system)
	if (!gladLoadGL()) {
		std::cout << "GLAD init failed" << std::endl;
		return;
	}

	//Query and print out information about our OpenGL environment
	QueryGLVersion();
}



void Program::QueryGLVersion() {
	// query opengl version and renderer information
	std::string version = reinterpret_cast<const char *>(glGetString(GL_VERSION));
	std::string glslver = reinterpret_cast<const char *>(glGetString(GL_SHADING_LANGUAGE_VERSION));
	std::string renderer = reinterpret_cast<const char *>(glGetString(GL_RENDERER));

	std::cout << "OpenGL [ " << version << " ] "
		<< "with GLSL [ " << glslver << " ] "
		<< "on renderer [ " << renderer << " ]" << std::endl;
}

void ErrorCallback(int error, const char* description) {
	std::cout << "GLFW ERROR " << error << ":" << std::endl;
	std::cout << description << std::endl;
}

void KeyCallback(GLFWwindow* window, int key, int scancode, int action, int mods) {
	//Key codes are often prefixed with GLFW_KEY_ and can be found on the GLFW website
	Program* program = (Program*)glfwGetWindowUserPointer(window);

	if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS) {
		glfwSetWindowShouldClose(window, GL_TRUE);
	}

	// tea pot
	if (key == GLFW_KEY_1 && action == GLFW_PRESS) {
		program->setDrawLineBoolean(0);
		program->getScene()->part1Scene1();
		program->setSceneID(1);
	}

	// fish
	if (key == GLFW_KEY_2 && action == GLFW_PRESS) {
		program->setDrawLineBoolean(0);
		program->getScene()->part1Scene2();
		program->setSceneID(2);
	}

	// name0
	if (key == GLFW_KEY_3 && action == GLFW_PRESS) {
		program->getScene()->drawName(0);
		program->setSceneID(3);
	}

	// name1
	if (key == GLFW_KEY_4 && action == GLFW_PRESS) {
		program->getScene()->drawName(1);
		program->setSceneID(3);
	}

	// name2
	if (key == GLFW_KEY_5 && action == GLFW_PRESS) {
		program->getScene()->drawName(2);
		program->setSceneID(3);
	}

	// sentence0
	if (key == GLFW_KEY_6 && action == GLFW_PRESS) {
		program->getScene()->scrollingText(0);
		program->setSceneID(4);
	}

	// sentence1
	if (key == GLFW_KEY_7 && action == GLFW_PRESS) {
		program->getScene()->scrollingText(1);
		program->setSceneID(4);
	}

	// sentence2
	if (key == GLFW_KEY_8 && action == GLFW_PRESS) {
		program->getScene()->scrollingText(2);
		program->setSceneID(4);
	}

	// draw control point and control polygon at the same time.
	if (key == GLFW_KEY_SPACE && action == GLFW_PRESS && ((program->getSceneID() == 1) || (program->getSceneID() == 2))) {
		if (program->getDrawLineBoolean()) {	// true
			program->setDrawLineBoolean(0);		// set to false
			if (program->getSceneID() == 1) {
				program->getScene()->part1Scene1();
			}
			else if (program->getSceneID() == 2) {
				program->getScene()->part1Scene2();	
			}
		}
		else {
			program->setDrawLineBoolean(1);		// set to true
			if (program->getSceneID() == 1) {
				program->getScene()->drawLine1();
				program->getScene()->drawPoint1();
			}
			else if (program->getSceneID() == 2){
				program->getScene()->drawLine2();
				program->getScene()->drawPoint2();
			}
		}
	}
}

//Detect the scroll
void scroll_callback(GLFWwindow* window, double xoffset, double yoffset) {
	Program* program = (Program*)glfwGetWindowUserPointer(window);
	if (yoffset == 1.0f) {
		if (program->getSpeed() < 90.0f) {
			program->setSpeed(program->getSpeed() + 5);	// zoom in
		}
	}
	else if (yoffset == -1.0f) {
		if (program->getSpeed() > 20.0f) {
			program->setSpeed(program->getSpeed() - 5);	// zoom out
		}
	}
	printf("Speed: %f\n", program->getSpeed());
}