Name: BenKun Chen (30005337)
      Jianan Ding (30026610)

INTRODUCTION:

The program is been eddited based on the boilerlplate code


CONTROLS:

1 - switch to Part 1: Bezier Curves 1st scene
2 - switch to Part 1: Bezier Curves 2nd scene
3 - switch to Part 2: Rendering Fonts 1st scene
4 - switch to Part 2: Rendering Fonts 2nd scene
5 - switch to Part 2: Rendering Fonts 3rd scene
6 - switch to Part 3: Scrolling Text 1st scene
7 - switch to Part 3: Scrolling Text 2nd scene
8 - switch to Part 3: Scrolling Text 3rd scene

SPACE - Enable/Disable the control polygon for Part 1: Bezier Curves

scroll up - decrease the speed
scroll down - increase the speed

Esc - exit the program
