/*
 * Scene.cpp
 *
 *  Created on: Sep 10, 2018
 *  Author: John Hall
 */

#include "Scene.h"

#include <iostream>
#include <bits/stdc++.h>		// include for have type 'string' key word

#include "RenderingEngine.h"

#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

//**Must include glad and GLFW in this order or it breaks**
#include <glad/glad.h>
#include <GLFW/glfw3.h>

#include "GlyphExtractor.h"

using namespace std;

Scene::Scene(RenderingEngine* renderer) : renderer(renderer) {

}

Scene::~Scene() {

}

void Scene::displayScene(float fps, int sceneID) {
	renderer->RenderScene(objects, fps, sceneID);
}

// Part I: Bezier Curves
void Scene::part1Scene1() {
	objects.clear();
	Geometry pot;

	pot.setState(0);		// set the state to draw the scene 1

	float scale = 0.4;
	pot.verts.push_back(glm::vec3( 1.0f * scale - 0.1f, 1.0f * scale, 1.0f));
	pot.verts.push_back(glm::vec3( 2.0f * scale - 0.1f, -1.0f * scale, 1.0f));
	pot.verts.push_back(glm::vec3( 0.0f * scale - 0.1f, -1.0f * scale, 1.0f));

	pot.verts.push_back(glm::vec3( 0.0f * scale - 0.1f, -1.0f * scale, 1.0f));
	pot.verts.push_back(glm::vec3( -2.0f * scale - 0.1f, -1.0f * scale, 1.0f));
	pot.verts.push_back(glm::vec3( -1.0f * scale - 0.1f, 1.0f * scale, 1.0f));

	pot.verts.push_back(glm::vec3( -1.0f * scale - 0.1f, 1.0f * scale, 1.0f));
	pot.verts.push_back(glm::vec3( 0.0f * scale - 0.1f, 1.0f * scale, 1.0f));
	pot.verts.push_back(glm::vec3( 1.0f * scale - 0.1f, 1.0f * scale, 1.0f));

	pot.verts.push_back(glm::vec3( 1.2f * scale - 0.1f, 0.5f * scale, 1.0f));
	pot.verts.push_back(glm::vec3( 2.5f * scale - 0.1f, 1.0f * scale, 1.0f));
	pot.verts.push_back(glm::vec3( 1.3f * scale - 0.1f, -0.4f * scale, 1.0f));

	for (int i = 0; i < pot.verts.size(); i++)
	{
		pot.colors.push_back(glm::vec3( 1.0f, 1.0f, 1.0f));
	}

	pot.drawMode = GL_PATCHES;
	RenderingEngine::assignBuffers(pot);
	RenderingEngine::setBufferData(pot);
	objects.push_back(pot);
}


// Part I: Bezier Curves
void Scene::drawLine1() {
	Geometry line1;
	line1.setState(2);		// set the state to draw the scene 1

	float scale = 0.4;
	line1.verts.push_back(glm::vec3( 1.0f * scale - 0.1f, 1.0f * scale, 1.0f));
	line1.verts.push_back(glm::vec3( 2.0f * scale - 0.1f, -1.0f * scale, 1.0f));
	line1.verts.push_back(glm::vec3( 2.0f * scale - 0.1f, -1.0f * scale, 1.0f));
	line1.verts.push_back(glm::vec3( 0.0f * scale - 0.1f, -1.0f * scale, 1.0f));

	line1.verts.push_back(glm::vec3( 0.0f * scale - 0.1f, -1.0f * scale, 1.0f));
	line1.verts.push_back(glm::vec3( -2.0f * scale - 0.1f, -1.0f * scale, 1.0f));
	line1.verts.push_back(glm::vec3( -2.0f * scale - 0.1f, -1.0f * scale, 1.0f));
	line1.verts.push_back(glm::vec3( -1.0f * scale - 0.1f, 1.0f * scale, 1.0f));

	line1.verts.push_back(glm::vec3( -1.0f * scale - 0.1f, 1.0f * scale, 1.0f));
	line1.verts.push_back(glm::vec3( 0.0f * scale - 0.1f, 1.0f * scale, 1.0f));
	line1.verts.push_back(glm::vec3( 0.0f * scale - 0.1f, 1.0f * scale, 1.0f));
	line1.verts.push_back(glm::vec3( 1.0f * scale - 0.1f, 1.0f * scale, 1.0f));

	line1.verts.push_back(glm::vec3( 1.2f * scale - 0.1f, 0.5f * scale, 1.0f));
	line1.verts.push_back(glm::vec3( 2.5f * scale - 0.1f, 1.0f * scale, 1.0f));
	line1.verts.push_back(glm::vec3( 2.5f * scale - 0.1f, 1.0f * scale, 1.0f));
	line1.verts.push_back(glm::vec3( 1.3f * scale - 0.1f, -0.4f * scale, 1.0f));

	for (int i = 0; i < line1.verts.size(); i++)
	{
		line1.colors.push_back(glm::vec3( 0.670f, 1.0f, 0.2f));
	}

	line1.drawMode = GL_PATCHES;

	RenderingEngine::assignBuffers(line1);
	RenderingEngine::setBufferData(line1);
	objects.push_back(line1);
}


// Part I: Bezier Curves
void Scene::drawPoint1() {
	Geometry point1;
	point1.setState(3);		// set the state to draw the scene 1

	float scale = 0.4;
	point1.verts.push_back(glm::vec3( 1.0f * scale - 0.1f, 1.0f * scale, 1.0f));
	point1.colors.push_back(glm::vec3( 0.670f, 1.0f, 0.2f));
	point1.verts.push_back(glm::vec3( 2.0f * scale - 0.1f, -1.0f * scale, 1.0f));
	point1.colors.push_back(glm::vec3( 0.376f, 0.549f, 0.921f));
	point1.verts.push_back(glm::vec3( 0.0f * scale - 0.1f, -1.0f * scale, 1.0f));
	point1.colors.push_back(glm::vec3( 0.670f, 1.0f, 0.2f));

	point1.verts.push_back(glm::vec3( 0.0f * scale - 0.1f, -1.0f * scale, 1.0f));
	point1.colors.push_back(glm::vec3( 0.670f, 1.0f, 0.2f));
	point1.verts.push_back(glm::vec3( -2.0f * scale - 0.1f, -1.0f * scale, 1.0f));
	point1.colors.push_back(glm::vec3( 0.376f, 0.549f, 0.921f));
	point1.verts.push_back(glm::vec3( -1.0f * scale - 0.1f, 1.0f * scale, 1.0f));
	point1.colors.push_back(glm::vec3( 0.670f, 1.0f, 0.2f));

	point1.verts.push_back(glm::vec3( -1.0f * scale - 0.1f, 1.0f * scale, 1.0f));
	point1.colors.push_back(glm::vec3( 0.670f, 1.0f, 0.2f));
	point1.verts.push_back(glm::vec3( 0.0f * scale - 0.1f, 1.0f * scale, 1.0f));
	point1.colors.push_back(glm::vec3( 0.376f, 0.549f, 0.921f));
	point1.verts.push_back(glm::vec3( 1.0f * scale - 0.1f, 1.0f * scale, 1.0f));
	point1.colors.push_back(glm::vec3( 0.670f, 1.0f, 0.2f));

	point1.verts.push_back(glm::vec3( 1.2f * scale - 0.1f, 0.5f * scale, 1.0f));
	point1.colors.push_back(glm::vec3( 0.670f, 1.0f, 0.2f));
	point1.verts.push_back(glm::vec3( 2.5f * scale - 0.1f, 1.0f * scale, 1.0f));
	point1.colors.push_back(glm::vec3( 0.376f, 0.549f, 0.921f));
	point1.verts.push_back(glm::vec3( 1.3f * scale - 0.1f, -0.4f * scale, 1.0f));
	point1.colors.push_back(glm::vec3( 0.670f, 1.0f, 0.2f));

	point1.drawMode = GL_PATCHES;

	RenderingEngine::assignBuffers(point1);
	RenderingEngine::setBufferData(point1);
	objects.push_back(point1);
}


// Part I: Bezier Curves
void Scene::part1Scene2() {
	objects.clear();
	Geometry fish;

	fish.setState(1);		// set the state to draw the scene 2

	float scale = 0.18;
	fish.verts.push_back(glm::vec3( 1.1f * scale -0.8f, 1.1f * scale -0.5f, 1.0f));
	fish.verts.push_back(glm::vec3( 4.0f * scale -0.8f, 0.0f * scale -0.5f, 1.0f));
	fish.verts.push_back(glm::vec3( 6.0f * scale -0.8f, 2.0f * scale -0.5f, 1.0f));
	fish.verts.push_back(glm::vec3( 9.0f * scale -0.8f, 1.0f * scale -0.5f, 1.0f));

	fish.verts.push_back(glm::vec3( 8.0f * scale -0.8f, 2.0f * scale -0.5f, 1.0f));
	fish.verts.push_back(glm::vec3( 0.0f * scale -0.8f, 8.0f * scale -0.5f, 1.0f));
	fish.verts.push_back(glm::vec3( 0.0f * scale -0.8f, -2.0f * scale -0.5f, 1.0f));
	fish.verts.push_back(glm::vec3( 8.0f * scale -0.8f, 4.0f * scale -0.5f, 1.0f));

	fish.verts.push_back(glm::vec3( 5.0f * scale -0.8f, 3.0f * scale -0.5f, 1.0f));
	fish.verts.push_back(glm::vec3( 3.0f * scale -0.8f, 2.0f * scale -0.5f, 1.0f));
	fish.verts.push_back(glm::vec3( 3.0f * scale -0.8f, 3.0f * scale -0.5f, 1.0f));
	fish.verts.push_back(glm::vec3( 5.0f * scale -0.8f, 2.0f * scale -0.5f, 1.0f));

	fish.verts.push_back(glm::vec3( 3.0f * scale -0.8f, 2.2f * scale -0.5f, 1.0f));
	fish.verts.push_back(glm::vec3( 3.5f * scale -0.8f, 2.7f * scale -0.5f, 1.0f));
	fish.verts.push_back(glm::vec3( 3.5f * scale -0.8f, 3.3f * scale -0.5f, 1.0f));
	fish.verts.push_back(glm::vec3( 3.0f * scale -0.8f, 3.8f * scale -0.5f, 1.0f));

	fish.verts.push_back(glm::vec3( 2.8f * scale -0.8f, 3.5f * scale -0.5f, 1.0f));
	fish.verts.push_back(glm::vec3( 2.4f * scale -0.8f, 3.8f * scale -0.5f, 1.0f));
	fish.verts.push_back(glm::vec3( 2.4f * scale -0.8f, 3.2f * scale -0.5f, 1.0f));
	fish.verts.push_back(glm::vec3( 2.8f * scale -0.8f, 3.5f * scale -0.5f, 1.0f));


	for (int i = 0; i < fish.verts.size(); i++)
	{
		fish.colors.push_back(glm::vec3( 1.0f, 1.0f, 1.0f));
	}

	fish.drawMode = GL_PATCHES;
	RenderingEngine::assignBuffers(fish);
	RenderingEngine::setBufferData(fish);
	objects.push_back(fish);
}


// Part I: Bezier Curves
void Scene::drawLine2() {
	Geometry line2;
	line2.setState(2);		// set the state to draw the line for scene 2

	float scale = 0.18;
	line2.verts.push_back(glm::vec3( 1.1f * scale -0.8f, 1.1f * scale -0.5f, 1.0f));
	line2.verts.push_back(glm::vec3( 4.0f * scale -0.8f, 0.0f * scale -0.5f, 1.0f));
	line2.verts.push_back(glm::vec3( 4.0f * scale -0.8f, 0.0f * scale -0.5f, 1.0f));
	line2.verts.push_back(glm::vec3( 6.0f * scale -0.8f, 2.0f * scale -0.5f, 1.0f));
	line2.verts.push_back(glm::vec3( 6.0f * scale -0.8f, 2.0f * scale -0.5f, 1.0f));
	line2.verts.push_back(glm::vec3( 9.0f * scale -0.8f, 1.0f * scale -0.5f, 1.0f));

	line2.verts.push_back(glm::vec3( 8.0f * scale -0.8f, 2.0f * scale -0.5f, 1.0f));
	line2.verts.push_back(glm::vec3( 0.0f * scale -0.8f, 8.0f * scale -0.5f, 1.0f));
	line2.verts.push_back(glm::vec3( 0.0f * scale -0.8f, 8.0f * scale -0.5f, 1.0f));
	line2.verts.push_back(glm::vec3( 0.0f * scale -0.8f, -2.0f * scale -0.5f, 1.0f));
	line2.verts.push_back(glm::vec3( 0.0f * scale -0.8f, -2.0f * scale -0.5f, 1.0f));
	line2.verts.push_back(glm::vec3( 8.0f * scale -0.8f, 4.0f * scale -0.5f, 1.0f));

	line2.verts.push_back(glm::vec3( 5.0f * scale -0.8f, 3.0f * scale -0.5f, 1.0f));
	line2.verts.push_back(glm::vec3( 3.0f * scale -0.8f, 2.0f * scale -0.5f, 1.0f));
	line2.verts.push_back(glm::vec3( 3.0f * scale -0.8f, 2.0f * scale -0.5f, 1.0f));
	line2.verts.push_back(glm::vec3( 3.0f * scale -0.8f, 3.0f * scale -0.5f, 1.0f));
	line2.verts.push_back(glm::vec3( 3.0f * scale -0.8f, 3.0f * scale -0.5f, 1.0f));
	line2.verts.push_back(glm::vec3( 5.0f * scale -0.8f, 2.0f * scale -0.5f, 1.0f));

	line2.verts.push_back(glm::vec3( 3.0f * scale -0.8f, 2.2f * scale -0.5f, 1.0f));
	line2.verts.push_back(glm::vec3( 3.5f * scale -0.8f, 2.7f * scale -0.5f, 1.0f));
	line2.verts.push_back(glm::vec3( 3.5f * scale -0.8f, 2.7f * scale -0.5f, 1.0f));
	line2.verts.push_back(glm::vec3( 3.5f * scale -0.8f, 3.3f * scale -0.5f, 1.0f));
	line2.verts.push_back(glm::vec3( 3.5f * scale -0.8f, 3.3f * scale -0.5f, 1.0f));
	line2.verts.push_back(glm::vec3( 3.0f * scale -0.8f, 3.8f * scale -0.5f, 1.0f));

	line2.verts.push_back(glm::vec3( 2.8f * scale -0.8f, 3.5f * scale -0.5f, 1.0f));
	line2.verts.push_back(glm::vec3( 2.4f * scale -0.8f, 3.8f * scale -0.5f, 1.0f));
	line2.verts.push_back(glm::vec3( 2.4f * scale -0.8f, 3.8f * scale -0.5f, 1.0f));
	line2.verts.push_back(glm::vec3( 2.4f * scale -0.8f, 3.2f * scale -0.5f, 1.0f));
	line2.verts.push_back(glm::vec3( 2.4f * scale -0.8f, 3.2f * scale -0.5f, 1.0f));
	line2.verts.push_back(glm::vec3( 2.8f * scale -0.8f, 3.5f * scale -0.5f, 1.0f));

	for (int i = 0; i < line2.verts.size(); i++)
	{
		line2.colors.push_back(glm::vec3( 0.670f, 1.0f, 0.2f));
	}

	line2.drawMode = GL_PATCHES;
	RenderingEngine::assignBuffers(line2);
	RenderingEngine::setBufferData(line2);
	objects.push_back(line2);
}


// Part I: Bezier Curves
void Scene::drawPoint2() {
	Geometry point2;

	point2.setState(3);		// set the state to draw the scene 2

	float scale = 0.18;
	point2.verts.push_back(glm::vec3( 1.1f * scale -0.8f, 1.1f * scale -0.5f, 1.0f));
	point2.colors.push_back(glm::vec3( 0.670f, 1.0f, 0.2f));
	point2.verts.push_back(glm::vec3( 4.0f * scale -0.8f, 0.0f * scale -0.5f, 1.0f));
	point2.colors.push_back(glm::vec3( 0.376f, 0.549f, 0.921f));
	point2.verts.push_back(glm::vec3( 6.0f * scale -0.8f, 2.0f * scale -0.5f, 1.0f));
	point2.colors.push_back(glm::vec3( 0.376f, 0.549f, 0.921f));
	point2.verts.push_back(glm::vec3( 9.0f * scale -0.8f, 1.0f * scale -0.5f, 1.0f));
	point2.colors.push_back(glm::vec3( 0.670f, 1.0f, 0.2f));
	
	point2.verts.push_back(glm::vec3( 8.0f * scale -0.8f, 2.0f * scale -0.5f, 1.0f));
	point2.colors.push_back(glm::vec3( 0.670f, 1.0f, 0.2f));
	point2.verts.push_back(glm::vec3( 0.0f * scale -0.8f, 8.0f * scale -0.5f, 1.0f));
	point2.colors.push_back(glm::vec3( 0.376f, 0.549f, 0.921f));
	point2.verts.push_back(glm::vec3( 0.0f * scale -0.8f, -2.0f * scale -0.5f, 1.0f));
	point2.colors.push_back(glm::vec3( 0.376f, 0.549f, 0.921f));
	point2.verts.push_back(glm::vec3( 8.0f * scale -0.8f, 4.0f * scale -0.5f, 1.0f));
	point2.colors.push_back(glm::vec3( 0.670f, 1.0f, 0.2f));

	point2.verts.push_back(glm::vec3( 5.0f * scale -0.8f, 3.0f * scale -0.5f, 1.0f));
	point2.colors.push_back(glm::vec3( 0.670f, 1.0f, 0.2f));
	point2.verts.push_back(glm::vec3( 3.0f * scale -0.8f, 2.0f * scale -0.5f, 1.0f));
	point2.colors.push_back(glm::vec3( 0.376f, 0.549f, 0.921f));
	point2.verts.push_back(glm::vec3( 3.0f * scale -0.8f, 3.0f * scale -0.5f, 1.0f));
	point2.colors.push_back(glm::vec3( 0.376f, 0.549f, 0.921f));
	point2.verts.push_back(glm::vec3( 5.0f * scale -0.8f, 2.0f * scale -0.5f, 1.0f));
	point2.colors.push_back(glm::vec3( 0.670f, 1.0f, 0.2f));
	
	point2.verts.push_back(glm::vec3( 3.0f * scale -0.8f, 2.2f * scale -0.5f, 1.0f));
	point2.colors.push_back(glm::vec3( 0.670f, 1.0f, 0.2f));
	point2.verts.push_back(glm::vec3( 3.5f * scale -0.8f, 2.7f * scale -0.5f, 1.0f));
	point2.colors.push_back(glm::vec3( 0.376f, 0.549f, 0.921f));
	point2.verts.push_back(glm::vec3( 3.5f * scale -0.8f, 3.3f * scale -0.5f, 1.0f));
	point2.colors.push_back(glm::vec3( 0.376f, 0.549f, 0.921f));
	point2.verts.push_back(glm::vec3( 3.0f * scale -0.8f, 3.8f * scale -0.5f, 1.0f));
	point2.colors.push_back(glm::vec3( 0.670f, 1.0f, 0.2f));

	point2.verts.push_back(glm::vec3( 2.8f * scale -0.8f, 3.5f * scale -0.5f, 1.0f));
	point2.colors.push_back(glm::vec3( 0.670f, 1.0f, 0.2f));
	point2.verts.push_back(glm::vec3( 2.4f * scale -0.8f, 3.8f * scale -0.5f, 1.0f));
	point2.colors.push_back(glm::vec3( 0.376f, 0.549f, 0.921f));
	point2.verts.push_back(glm::vec3( 2.4f * scale -0.8f, 3.2f * scale -0.5f, 1.0f));
	point2.colors.push_back(glm::vec3( 0.376f, 0.549f, 0.921f));
	point2.verts.push_back(glm::vec3( 2.8f * scale -0.8f, 3.5f * scale -0.5f, 1.0f));
	point2.colors.push_back(glm::vec3( 0.670f, 1.0f, 0.2f));

	point2.drawMode = GL_PATCHES;
	RenderingEngine::assignBuffers(point2);
	RenderingEngine::setBufferData(point2);
	objects.push_back(point2);
}

// Part II: Rendering Fonts
void Scene::drawName(int fontNum) {
	objects.clear();
	Geometry name;

	string fonts[3] = {"fonts/source-sans-pro/SourceSansPro-Regular.otf",
						"fonts/lora/Lora-Regular.ttf", 
						"fonts/amatic/AmaticSC-Regular.ttf"};

	GlyphExtractor g;
	g.LoadFontFile(fonts[fontNum]);

	char stephen[7] = {'S', 't', 'e', 'p', 'h', 'e', 'n'};
		
	float space = -0.75f;
	float scale = 0.4f;
	
	for (int s = 0; s < sizeof(stephen); s++) {
		MyGlyph a = g.ExtractGlyph(stephen[s]);
		for (unsigned int i = 0; i < a.contours.size(); i++) {
			for(unsigned int j = 0; j < a.contours[i].size(); j++) {
				if (a.contours[i][j].degree == 1) {			// 2 points
					name.setState(2);
				}
				else if (a.contours[i][j].degree == 2) {	// 3 points
					name.setState(0);
				}
				else if (a.contours[i][j].degree == 3) {	// 4 points
					name.setState(1);
				}
				for(unsigned int k = 0; k <= a.contours[i][j].degree; k++) {
					name.verts.push_back(glm::vec3(a.contours[i][j].x[k] * scale + space, a.contours[i][j].y[k] * scale + 0.3, 1.0f));
					name.colors.push_back(glm::vec3(0.67f, 1.0f, 0.2f));
				}
				name.drawMode = GL_PATCHES;
				RenderingEngine::assignBuffers(name);
				RenderingEngine::setBufferData(name);
				objects.push_back(name);
				name.verts.clear();
			}
		}
		space += a.advance * scale;
	}

	char ben[3] = {'B', 'e', 'n'};
	
	space = -0.35f;
	
	for (int s = 0; s < sizeof(ben); s++) {
		MyGlyph a = g.ExtractGlyph(ben[s]);
		for (unsigned int i = 0; i < a.contours.size(); i++) {
			for(unsigned int j = 0; j < a.contours[i].size(); j++) {
				if (a.contours[i][j].degree == 1) {			// 2 points
					name.setState(2);
				}
				else if (a.contours[i][j].degree == 2){		// 3 points
					name.setState(0);
				}
				else if (a.contours[i][j].degree == 3) {	// 4 points
					name.setState(1);
				}
				for(unsigned int k = 0; k <= a.contours[i][j].degree; k++) {
					name.verts.push_back(glm::vec3(a.contours[i][j].x[k] * scale + space, a.contours[i][j].y[k] * scale - 0.3, 1.0f));
					name.colors.push_back(glm::vec3(0.67f, 1.0f, 0.2f));
				}
				name.drawMode = GL_PATCHES;
				RenderingEngine::assignBuffers(name);
				RenderingEngine::setBufferData(name);
				objects.push_back(name);
				name.verts.clear();
			}
		}
		space += a.advance * scale;
	}
}


// Part III: Scrolling Text
void Scene::scrollingText(int fontID) {
	objects.clear();
	Geometry text;

	string fonts[3] = {"fonts//alex-brush/AlexBrush-Regular.ttf",
						"fonts/inconsolata/Inconsolata.otf",
						"fonts/amatic/AmaticSC-Regular.ttf"};

	GlyphExtractor g;
	g.LoadFontFile(fonts[fontID]);

	string sentence = "The quick brown fox jumps over the lazy dog.";

	float space = 1.0f;
	float scale = 0.6f;
	
	for (int s = 0; s < 44; s++) {
		MyGlyph a = g.ExtractGlyph(sentence[s]);
		for (unsigned int i = 0; i < a.contours.size(); i++) {
			for(unsigned int j = 0; j < a.contours[i].size(); j++) {
				if (a.contours[i][j].degree == 1) {			// 2 points
					text.setState(2);
				}
				else if (a.contours[i][j].degree == 2) {	// 3 points
					text.setState(0);
				}
				else if (a.contours[i][j].degree == 3) {	// 4 points
					text.setState(1);
				}
				for(unsigned int k = 0; k <= a.contours[i][j].degree; k++) {
					text.verts.push_back(glm::vec3(a.contours[i][j].x[k] * scale + space, a.contours[i][j].y[k] * scale -0.2f, 1.0f));
					text.colors.push_back(glm::vec3(0.67f, 1.0f, 0.2f));
				}
				text.drawMode = GL_PATCHES;
				RenderingEngine::assignBuffers(text);
				RenderingEngine::setBufferData(text);
				objects.push_back(text);
				text.verts.clear();
			}
		}
		space += a.advance * scale;
	}
	text.drawMode = GL_PATCHES;
	RenderingEngine::assignBuffers(text);
	RenderingEngine::setBufferData(text);
	objects.push_back(text);
	text.verts.clear();
}