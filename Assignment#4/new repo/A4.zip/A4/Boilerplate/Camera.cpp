/*
* Camera.cpp
*
* Created on: Nov 11, 2018
*     Author: Heavenel Cerna
*/

#include "Camera.h"

Camera::Camera(float angle) {
	fov = angle;
}

Camera::~Camera() {
}
