Name: BenKun Chen (30005337)

INTRODUCTION:

The program is been eddited based on the boilerlplate code for eclipse


CONTROLS:

1 - switch to Square & Diamonds scene
2 - switch to Parametric Sprial scene
3 - switch to Sierpinski Triangle scene
4 - switch to Sierpinski Triangle Reloaded scene

up arrow key - iteration up 
down arrow key - iteration down 


